Instrukcja: Zainstaluj HeliosPulse.user.js w Tampermonkey, GoogleAppsScript_Code.gs w Apps Script.
Config.json zawiera dane konfiguracji.
